<?php 

/*************
 * Product Box Style
 *************/

Flatsome_Option::add_section( 'product-box', array(
	'title'       => __( 'Product Box', 'flatsome-admin' ),
	'panel' => 'shop'
) );



