package txnam.intentexample2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {

	TextView tv;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		tv = (TextView) findViewById(R.id.textView1);
	}
	
	public void btnA(View v) {
		startActivityForResult(new Intent(this, FirstActivity.class), 1000);
	}

	public void btnB(View v) {
		startActivityForResult(new Intent(this, SecondActivity.class), 2000);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// nếu kết quả trả về từ FirstActivity
		if (requestCode == 1000) {
			if (resultCode == RESULT_CANCELED) tv.setText("FirstActivity đã hủy nhập liệu");
			else {
				String u = data.getStringExtra("user");
				String p = data.getStringExtra("pass");
				tv.setText("FirstActivity nhập " + u + "(" + p + ")");
			}
			return;
		}
		
		// nếu kết quả trả về từ SecondActivity
		if (requestCode == 2000) {
			if (resultCode == RESULT_CANCELED) tv.setText("SecondActivity đã hủy nhập liệu");
			else {
				String id = data.getStringExtra("id");
				tv.setText("FirstActivity nhập id = " + id);
			}
			return;
		}
				
		super.onActivityResult(requestCode, resultCode, data);
	}
}
