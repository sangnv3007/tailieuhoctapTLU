package txnam.intentexample2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class SecondActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);
	}
	
	public void btnSend(View v) {
		Intent x = new Intent();
		
		EditText ed = (EditText) findViewById(R.id.editText1);
		x.putExtra("id", ed.getText().toString());
		
		setResult(RESULT_OK, x);
		
		finish();

	}
	
	public void btnCancel(View v) {
		setResult(RESULT_CANCELED);
		finish();
	}
}
