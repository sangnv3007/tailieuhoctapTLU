package txnam.helloworld;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class SecondActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);
	}
	
	public void btnTinhTong(View v) {
		EditText soA = (EditText) findViewById(R.id.editText1);
		EditText soB = (EditText) findViewById(R.id.editText2);
		
		String a = soA.getText().toString();
		String b = soB.getText().toString();
		
		int x = Integer.parseInt(a);
		int y = Integer.parseInt(b);
		
		int tong = x+y;
		
		Toast.makeText(this, "Tổng 2 số là " + tong, Toast.LENGTH_LONG).show();
		
		Button btn = (Button) findViewById(R.id.button1);
		btn.setBackgroundColor(Color.MAGENTA);
	}
	
	public void btnQuit(View v) {
		finish();
	}
	
	public void btnBam(View v) {
		CheckBox cb = (CheckBox) findViewById(R.id.checkBox1);
		boolean b = cb.isChecked();
		cb.setChecked(!b);
	}
}
