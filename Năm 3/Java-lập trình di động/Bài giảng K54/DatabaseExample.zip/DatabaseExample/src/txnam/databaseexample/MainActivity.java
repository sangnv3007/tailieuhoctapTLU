package txnam.databaseexample;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	SQLiteDatabase db = null;
	Button bFirst, bPrev, bNext, bLast;
	TextView tvId, tvName, tvPage, tvPrice, tvDes;
	Cursor cs = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		bFirst = (Button) findViewById(R.id.button3);
		bPrev = (Button) findViewById(R.id.button4);
		bNext = (Button) findViewById(R.id.button5);
		bLast = (Button) findViewById(R.id.button6);
		tvId = (TextView) findViewById(R.id.textView6);
		tvName = (TextView) findViewById(R.id.textView7);
		tvPage = (TextView) findViewById(R.id.textView8);
		tvPrice = (TextView) findViewById(R.id.textView9);
		tvDes = (TextView) findViewById(R.id.textView10);
	}
	
	boolean isNotOK() {
		if (db == null) {
			Toast.makeText(this, "Hãy tạo CSDL trước!!!", Toast.LENGTH_SHORT).show();
			return true;
		}
		
		return false;
	}
	
	public void btnFirst(View v) {
		if (isNotOK()) return;
		cs.moveToFirst();
		updateView();
	}
	
	public void btnPrev(View v) {
		if (isNotOK()) return;
		cs.moveToPrevious();
		updateView();
	}
	
	public void btnNext(View v) {
		if (isNotOK()) return;
		cs.moveToNext();
		updateView();
	}
	
	public void btnLast(View v) {
		if (isNotOK()) return;
		cs.moveToLast();
		updateView();
	}
	
	public void btnCreateDB(View v) {
		String sqltext = "DROP TABLE IF EXISTS BOOKS;\n"
				+ "CREATE TABLE BOOKS(BookID integer PRIMARY KEY, BookName text, Page integer, Price Float, Description text);\n"
				+ "INSERT INTO BOOKS VALUES(1, 'Java', 100, 9.99, 'sách về java');\n"
				+ "INSERT INTO BOOKS VALUES(2, 'Android', 320, 19.00, 'Android cơ bản');\n"
				+ "INSERT INTO BOOKS VALUES(3, 'Học làm giàu', 120, 0.99, 'sách đọc cho vui');\n"
				+ "INSERT INTO BOOKS VALUES(4, 'Tử điển Anh-Việt', 1000, 29.50, 'Từ điển 100.000 từ');\n"
				+ "INSERT INTO BOOKS VALUES(5, 'CNXH', 1, 1, 'chuyện cổ tích');";
		db = openOrCreateDatabase("books.db", MODE_PRIVATE, null);
		for (String sql : sqltext.split("\n"))
		    db.execSQL(sql);
		
		Toast.makeText(this, "Đã tạo mới CSDL Books với 5 bản ghi", Toast.LENGTH_LONG).show();
		
		cs = db.rawQuery("SELECT * FROM BOOKS", null);
		cs.moveToNext();
		updateView();
	}
	
	void updateView() {
		tvId.setText(cs.getString(0));
	    tvName.setText(cs.getString(1));
	    tvPage.setText(cs.getString(2));
	    tvPrice.setText(cs.getString(3));
	    tvDes.setText(cs.getString(4));
	    
	    bFirst.setEnabled(!cs.isFirst());
	    bPrev.setEnabled(!cs.isFirst());
	    bNext.setEnabled(!cs.isLast());
	    bLast.setEnabled(!cs.isLast());
	}

	public void btnQuit(View v) {
		if (db != null)
			db.close();
		finish();
	}
	
	public void onBackPressed() {
		if (db != null)
			db.close();
		super.onBackPressed();
	}
}
