/** Automatically generated file. DO NOT MODIFY */
package txnam.intentexample1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}