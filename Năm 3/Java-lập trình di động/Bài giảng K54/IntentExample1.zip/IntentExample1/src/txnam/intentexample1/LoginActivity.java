package txnam.intentexample1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class LoginActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		TextView tv = (TextView) findViewById(R.id.textView1);
		
		Intent x = getIntent();
		
		String u = x.getStringExtra("tendung");
		String p = x.getStringExtra("matkhau");
		
		tv.setText("Logging with " + u + "(" + p + ")");
	}
}
