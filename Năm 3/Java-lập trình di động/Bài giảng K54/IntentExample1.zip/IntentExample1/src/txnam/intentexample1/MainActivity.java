package txnam.intentexample1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends Activity {

	EditText user, pass;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		user = (EditText) findViewById(R.id.editText1);
		pass = (EditText) findViewById(R.id.editText2);
	}
	
	public void btnExit(View v) {
		finish();
	}
	
	public void btnClear(View v) {
		user.setText("");
		pass.setText("");
	}
	
	public void btnLogin(View v) {
		Intent x = new Intent(this, LoginActivity.class);
		
		String u = user.getText().toString();
		String p = pass.getText().toString();
		
		x.putExtra("tendung", u);
		x.putExtra("matkhau", p);
		
		startActivity(x);
	}
}
