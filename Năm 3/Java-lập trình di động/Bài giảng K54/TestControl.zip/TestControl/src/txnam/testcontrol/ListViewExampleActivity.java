package txnam.testcontrol;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

public class ListViewExampleActivity extends Activity {

	String[] values = new String[] { "Việt Nam", "Trung Quốc", "Triều Tiên", "Cuba", "Hoa Kỳ", "Lào", "Campuchia", "Nhật", "Úc", "Ấn Độ", "Anh", "Pháp" };
	String[] skins = new String[] { "Da Trắng", "Da Vàng", "Da Đen", "Da Đỏ", "Nhiều Màu" };

	ListView list;
	TextView text;
	Spinner sp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list_view_example);

		text = (TextView) findViewById(R.id.textView1);

		// tạo đối tượng lưu trữ các string được hiển thị lên ListView
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,
				android.R.id.text1, values);
		list = (ListView) findViewById(R.id.listView1);
		list.setAdapter(adapter);
		// xử lý sự kiện khi người dùng bấm vào 1 dòng của ListView
		list.setOnItemClickListener(new OnItemClickListener() {
			   @Override
			   public void onItemClick(
			      AdapterView<?> parent, View view, int pos, long id) {
			      String val = (String) list.getItemAtPosition(pos);
			      text.setText("Bạn chọn:" + val);
			   }
			});
		
		// thiết lập dữ liệu cho spinner
		sp = (Spinner) findViewById(R.id.spinner1);
		ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, skins);
		sp.setAdapter(adapter2);
	}
}
