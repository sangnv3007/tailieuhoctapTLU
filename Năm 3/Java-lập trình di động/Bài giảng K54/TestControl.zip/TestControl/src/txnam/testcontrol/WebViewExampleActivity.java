package txnam.testcontrol;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;

public class WebViewExampleActivity extends Activity {

	WebView wv;
	EditText et;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_web_view_example);
		
		wv = (WebView) findViewById(R.id.webView1);
		et = (EditText) findViewById(R.id.editText1);
	}
	
	public void btnGo(View v) {
		wv.loadUrl(et.getText().toString());
	}
	
	public void btnShow(View v) {
		wv.loadDataWithBaseURL("", et.getText().toString(), "text/html", "utf-8", "");
	}
}
