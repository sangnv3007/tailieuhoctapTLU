package txnam.testcontrol;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

public class ProgressBarActivity extends Activity {

	Handler myHandler = new Handler();
	int myPercent = 0;
	ProgressBar myProgress;
	TextView tv;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_progress_bar);
		myProgress = (ProgressBar) findViewById(R.id.progressBar2);
		tv = (TextView) findViewById(R.id.textView1);
		SeekBar sb = (SeekBar) findViewById(R.id.seekBar1);
		sb.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				tv.setText(""+progress);
			}
		});
	}
	
	public void btnRun(View v) {
		new Thread(new Runnable() {
			   public void run() {
			      for (int i = 0; i < 100; i++) {
			         try {
			        	 Thread.sleep(200);
			         }
			         catch (Exception ex) {}
			         myHandler.post(new Runnable() {
			            public void run() {
			               myProgress.setProgress(myPercent++);
			            }
			         });
			      }
			   }
			}).start();
	}
}
