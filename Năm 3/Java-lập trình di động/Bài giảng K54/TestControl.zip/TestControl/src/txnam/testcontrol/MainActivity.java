package txnam.testcontrol;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	public void btnProgressBar(View v) {
		Intent x = new Intent(this, ProgressBarActivity.class);
		startActivity(x);
	}
	
	public void btnProgressDialog(View v) {
		ProgressDialog pb = new ProgressDialog(this);
		pb.setCancelable(true);
		pb.setMessage("File downloading...");
		pb.setProgressStyle(
			 ProgressDialog.STYLE_HORIZONTAL);
		pb.setProgress(0);
		pb.setMax(100);
		pb.show();
	}
	
	public void btnListView(View v) {
		Intent x = new Intent(this, ListViewExampleActivity.class);
		startActivity(x);
	}

	public void btnWebView(View v) {
		Intent x = new Intent(this, WebViewExampleActivity.class);
		startActivity(x);
	}
}
