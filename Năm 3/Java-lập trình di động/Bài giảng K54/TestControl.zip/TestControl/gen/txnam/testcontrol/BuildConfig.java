/** Automatically generated file. DO NOT MODIFY */
package txnam.testcontrol;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}