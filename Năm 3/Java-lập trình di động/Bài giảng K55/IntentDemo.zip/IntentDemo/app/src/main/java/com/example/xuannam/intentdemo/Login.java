package com.example.xuannam.intentdemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Login extends AppCompatActivity {

    EditText name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Intent x = getIntent();
        String n = x.getStringExtra("loginname");
        name = (EditText) findViewById(R.id.editText);
        name.setText(n);
    }

    public void btnHuy(View v) {
        setResult(RESULT_CANCELED);
        finish();
    }

    public void btnOK(View v) {
        Intent x = new Intent();
        x.putExtra("newname", name.getText().toString());
        setResult(RESULT_OK, x);
        finish();
    }
}
