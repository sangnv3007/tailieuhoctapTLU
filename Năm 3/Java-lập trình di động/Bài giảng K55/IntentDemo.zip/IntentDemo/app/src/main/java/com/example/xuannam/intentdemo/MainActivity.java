package com.example.xuannam.intentdemo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView mImageView;
    EditText name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mImageView = (ImageView) findViewById(R.id.imageView);
        name = (EditText) findViewById(R.id.editText3);
    }

    public void btn1(View v) {
        Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:0912102165"));
        startActivity(dialIntent);
    }

    public void btn2(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("http://txnam.net"));
        startActivity(i);
    }

    public void btn3(View v) {
        Intent x = new Intent(this, Login.class);
        x.putExtra("loginname", name.getText().toString());
        startActivityForResult(x, 200);
    }

    public void btn4(View v) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePictureIntent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100 && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            mImageView.setImageBitmap(imageBitmap);
        }

        if (requestCode == 200)
            if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "Người dùng hủy cập nhật", Toast.LENGTH_LONG).show();
            }
            else {
                name.setText(data.getStringExtra("newname"));
                Toast.makeText(this, "Cập nhật thành công", Toast.LENGTH_LONG).show();
            }
    }
}
