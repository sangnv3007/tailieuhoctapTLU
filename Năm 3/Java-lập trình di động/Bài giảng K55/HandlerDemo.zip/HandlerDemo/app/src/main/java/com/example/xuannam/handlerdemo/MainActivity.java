package com.example.xuannam.handlerdemo;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView content;
    int count = 0;

    final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            content.setText(content.getText() + "Dữ liệu X: " + msg.getData().getString("x") + "\n");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        content = (TextView) findViewById(R.id.textView);
    }

    public void btnStart(View v) {
        background.start();
    }

    public void btnStartRunnable(View v) {
        background2.start();
    }

    Thread background2 = new Thread(new Runnable() {
        public void run() {
            while(true) {
                try {
                    Thread.sleep(500);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            content.setText(content.getText() + "Dữ liệu Y: $" + count++ +"\n");
                        }
                    });
                } catch (Exception e) {}
            }
        }
    });

    Thread background = new Thread(new Runnable() {
        public void run() {
            int i = 0;
            while(true) {
                try {
                    Thread.sleep(1000);
                    Message msg = new Message();
                    Bundle b = new Bundle();
                    b.putString("x", "~ " + i++);
                    msg.setData(b);
                    handler.sendMessage(msg);
                } catch (Exception e) {}
            }
        }
    });
}
