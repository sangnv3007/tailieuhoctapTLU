package com.example.xuannam.progressdemo;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Handler myHandler = new Handler();
    ProgressBar myProgress;
    int myPercent = 0;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myProgress = (ProgressBar) findViewById(R.id.progressBar2);
        tv = (TextView) findViewById(R.id.textView);
    }

    void doSomethingHere() {
        try {
            Thread.sleep(100);
        }
        catch (Exception e) {}
    }

    public void btnStart(View v) {
        new Thread(new Runnable() {
            public void run() {
                for (int i = 0; i < 100; i++) {
                    doSomethingHere();
                    myHandler.post(new Runnable() {
                        public void run() {
                            myProgress.setProgress(myPercent++);
                            tv.setText("" + myPercent);
                        }
                    });
                }
            }
        }).start();
    }
}
