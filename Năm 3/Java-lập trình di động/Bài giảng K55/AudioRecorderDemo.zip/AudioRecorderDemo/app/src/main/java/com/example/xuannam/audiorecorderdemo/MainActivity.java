package com.example.xuannam.audiorecorderdemo;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    EditText filename;
    TextView log;

    MediaRecorder recorder;

    File filemp3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        filename = (EditText) findViewById(R.id.editText);
        log = (TextView) findViewById(R.id.textView2);
    }

    void addLog(String str) {
        log.append("\n" + str);
    }

    void addToMediaStoreDB() {
        try {
            int now = (int) (System.currentTimeMillis() / 1000);
            ContentValues newValues = new ContentValues(6);
            newValues.put(MediaStore.MediaColumns.TITLE, filemp3.getName());
            newValues.put(MediaStore.MediaColumns.DATE_ADDED, now);
            newValues.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg");
            newValues.put(MediaStore.Audio.AudioColumns.IS_MUSIC, true);
            newValues.put(MediaStore.Audio.AudioColumns.ARTIST, "txnam");
            newValues.put(MediaStore.MediaColumns.DATA, filemp3.getAbsolutePath());
            ContentResolver contentResolver = getContentResolver();
            Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            Uri nUri = contentResolver.insert(base, newValues);
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, nUri));
        } catch (Exception ex) {
            Toast.makeText(this, "Error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void btnStart(View v) {
        try {
            File dir = Environment.getExternalStorageDirectory();
            filemp3 = File.createTempFile(filename.getText().toString(), ".3gp", dir);
            addLog("Create file: " + filemp3.getAbsolutePath());
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            recorder.setOutputFile(filemp3.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            addLog("Starting...");
        } catch (Exception ex) {
            Toast.makeText(this, "Error: " + ex.toString(), Toast.LENGTH_LONG).show();
        }
    }

    public void btnStop(View v) {
        try {
            recorder.stop();
            recorder.release();
            addLog("Stopped");
            addToMediaStoreDB();
            addLog("Add to MediaStoreDB: OK");
        } catch (Exception ex) {
            Toast.makeText(this, "Error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void btnPlay(View v) {
        try {
            String name = filemp3.getAbsolutePath();
            addLog("Now playing: " + name);
            MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(name);
            mp.prepare();
            mp.start();
        } catch (Exception ex) {
            Toast.makeText(this, "Error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
