package com.example.xuannam.databasedemo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText book_id, book_name, book_page, book_price, book_des;
    Button bPrev, bNext;
    SQLiteDatabase db;
    Cursor cs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createBookDatabase();
        initDB();
    }

    void initDB() {
        book_id = (EditText) findViewById(R.id.editText3);
        book_name = (EditText) findViewById(R.id.editText4);
        book_page = (EditText) findViewById(R.id.editText5);
        book_price = (EditText) findViewById(R.id.editText6);
        book_des = (EditText) findViewById(R.id.editText7);
        bPrev = (Button) findViewById(R.id.button);
        bNext = (Button) findViewById(R.id.button2);
        try {
            db = openOrCreateDatabase("books.db", MODE_PRIVATE, null);
            cs = db.rawQuery("SELECT * FROM BOOKS", null);
        }
        catch (Exception e) {
            finish();
        }
        cs.moveToNext();
        updateRecord();
    }

    void updateRecord() {
        book_id.setText(cs.getString(0));
        book_name.setText(cs.getString(1));
        book_page.setText(cs.getString(2));
        book_price.setText(cs.getString(3));
        book_des.setText(cs.getString(4));
        bPrev.setEnabled(!cs.isFirst());
        bNext.setEnabled(!cs.isLast());
    }

    public void btnPrev(View v) {
        cs.moveToPrevious();
        updateRecord();
    }

    public void btnNext(View v) {
        cs.moveToNext();
        updateRecord();
    }

    public void onBackPressed(){
        cs.close();
        db.close();
        super.onBackPressed();
    }

    void createBookDatabase() {
        String sqltext = "DROP TABLE IF EXISTS BOOKS;\n"
                + "CREATE TABLE BOOKS(BookID integer PRIMARY KEY, BookName text, Page integer, Price Float, Description text);\n"
                + "INSERT INTO BOOKS VALUES(1, 'Java', 100, 9.99, 'sách về java');\n"
                + "INSERT INTO BOOKS VALUES(2, 'Android', 320, 19.00, 'Android cơ bản');\n"
                + "INSERT INTO BOOKS VALUES(3, 'Học làm giàu', 120, 0.99, 'sách đọc cho vui');\n"
                + "INSERT INTO BOOKS VALUES(4, 'Tử điển Anh-Việt', 1000, 29.50, 'Từ điển 100.000 từ');\n"
                + "INSERT INTO BOOKS VALUES(5, 'CNXH', 1, 1, 'chuyện cổ tích');";
        // tạo DB và thực hiện một số câu SQL
        SQLiteDatabase db = openOrCreateDatabase("books.db", MODE_PRIVATE, null);
        for (String sql : sqltext.split("\n"))
            db.execSQL(sql);
        db.close();
    }
}
