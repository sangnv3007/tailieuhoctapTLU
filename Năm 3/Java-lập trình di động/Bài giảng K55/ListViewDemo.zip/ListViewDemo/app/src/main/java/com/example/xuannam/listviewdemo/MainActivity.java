package com.example.xuannam.listviewdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // mỗi string là 1 dòng trong ListView
    String[] values = new String[] {
        "Việt Nam", "Trung Quốc", "Triều Tiên", "Cuba", "Hoa Kỳ", "Liên bang Nga",
            "Anh", "Pháp", "Nhật Bản", "Hàn Quốc"
    };

    ListView listView;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.textView);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1,
                android.R.id.text1, values);
        listView = (ListView) findViewById(R.id.countryList);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(
                    AdapterView<?> parent, View view, int pos, long id) {
                String val = (String) listView.getItemAtPosition(pos);
                textView.setText(val);
            }
        });
    }
}
