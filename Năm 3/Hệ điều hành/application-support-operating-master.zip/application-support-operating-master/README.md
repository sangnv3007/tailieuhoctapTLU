﻿# Appication suport operator
Môn hệ điều hành
1. Clone or Download file .zip (->winzza).
2. Open file in unicode/app-unikey-operator.csproj. (Open with APP: Visual studio).
3. Read file Programm.cs to understand => Insert in Báo cáo.
